#include "../header/Edge.h"

Edge::Edge(Vertex* a, Vertex* b)
{
    this->a = a;
    this->b = b;
}

Vertex* Edge::nextVertex(const Vertex* vertex)
{
    if (vertex == a)
        return b;
    if (vertex == b)
        return a;

    return nullptr;
}