#ifndef VERTEX_H
#define VERTEX_H

class Vertex
{
public:
    int value;
    Vertex(int m_value):value{m_value}{}
};

#endif