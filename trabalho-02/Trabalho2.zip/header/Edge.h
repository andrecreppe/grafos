//
// Created by angelo on 03/04/23.
//

#ifndef EDGE_H
#define EDGE_H

#include "Vertex.h"

class Edge{
public:
    Vertex* a;
    Vertex* b;

    Edge(Vertex* a, Vertex* b);

    Vertex* nextVertex(const Vertex* vertex);
};


#endif
